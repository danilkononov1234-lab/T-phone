#include <Arduino.h>
#include <Wire.h>
#include <Arduino_GFX_Library.h>
#include <JPEGDEC.h>
#include "config.h"

#ifndef BLACK
#define BLACK 0x0000
#endif
#ifndef WHITE
#define WHITE 0xFFFF
#endif

static const uint8_t FRAME_MAGIC[4] = {'T','R','F','1'};
static const uint8_t TOUCH_MAGIC[4] = {'T','R','T','1'};

Arduino_ESP32PAR8Q *bus = nullptr;
Arduino_GFX *gfx = nullptr;
JPEGDEC jpeg;
uint8_t *jpegBuf = nullptr;
size_t jpegLen = 0;

int jpegDraw(JPEGDRAW *d) {
  gfx->draw16bitRGBBitmap(d->x, d->y, d->pPixels, d->iWidth, d->iHeight);
  return 1;
}

bool readExact(uint8_t *dst, size_t n, uint32_t timeoutMs = 2500) {
  size_t got = 0;
  uint32_t start = millis();
  while (got < n && millis() - start < timeoutMs) {
    int avail = Serial.available();
    if (avail > 0) {
      int take = min((size_t)avail, n - got);
      int r = Serial.readBytes((char *)(dst + got), take);
      if (r > 0) got += (size_t)r;
    } else {
      delay(1);
    }
  }
  return got == n;
}

uint32_t readLE32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
         ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

void showSplash(const char *a, const char *b = "") {
  gfx->fillScreen(BLACK);
  gfx->setTextColor(WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(8, 95);
  gfx->println("T-REMOTE");
  gfx->setTextSize(1);
  gfx->setCursor(8, 135);
  gfx->println(a);
  gfx->setCursor(8, 153);
  gfx->println(b);
}

void initDisplay() {
  pinMode(PIN_POWER_ON, OUTPUT);
  digitalWrite(PIN_POWER_ON, HIGH);
  pinMode(PIN_LCD_BL, OUTPUT);
  digitalWrite(PIN_LCD_BL, HIGH);

  bus = new Arduino_ESP32PAR8Q(
    PIN_LCD_DC, PIN_LCD_CS, PIN_LCD_WR, PIN_LCD_RD,
    PIN_LCD_D0, PIN_LCD_D1, PIN_LCD_D2, PIN_LCD_D3,
    PIN_LCD_D4, PIN_LCD_D5, PIN_LCD_D6, PIN_LCD_D7
  );
  gfx = new Arduino_ST7789(bus, PIN_LCD_RST, 0, true,
                           LCD_WIDTH, LCD_HEIGHT, 0, 0, 0, 0);
  gfx->begin();
  showSplash("USB CDC waiting");
}

bool touchRead(uint16_t &x, uint16_t &y, bool &down) {
  Wire.beginTransmission(TOUCH_I2C_ADDR);
  Wire.write(0x02);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(TOUCH_I2C_ADDR, (uint8_t)5) != 5) return false;
  uint8_t fingers = Wire.read();
  uint8_t xh = Wire.read(), xl = Wire.read();
  uint8_t yh = Wire.read(), yl = Wire.read();
  down = fingers != 0;
  x = ((xh & 0x0F) << 8) | xl;
  y = ((yh & 0x0F) << 8) | yl;
  if (x >= LCD_WIDTH || y >= LCD_HEIGHT) return false;
  return true;
}

void sendTouch(uint16_t x, uint16_t y, uint8_t state) {
  uint8_t p[9] = {
    TOUCH_MAGIC[0], TOUCH_MAGIC[1], TOUCH_MAGIC[2], TOUCH_MAGIC[3],
    (uint8_t)(x & 0xff), (uint8_t)(x >> 8),
    (uint8_t)(y & 0xff), (uint8_t)(y >> 8), state
  };
  Serial.write(p, sizeof(p));
  Serial.flush();
}

void pollTouch() {
  static bool wasDown = false;
  static uint32_t lastSent = 0;
  uint16_t x = 0, y = 0;
  bool down = false;
  if (!touchRead(x, y, down)) return;
  uint32_t now = millis();
  if (down && (!wasDown || now - lastSent > 120)) {
    sendTouch(x, y, 1);
    lastSent = now;
  }
  if (!down && wasDown) sendTouch(0, 0, 0);
  wasDown = down;
}

void processUsbFrame() {
  if (Serial.available() < 8) return;
  uint8_t header[8];
  if (!readExact(header, sizeof(header), 100)) return;

  if (memcmp(header, FRAME_MAGIC, 4) != 0) {
    // Re-sync by scanning for next magic on subsequent loop iterations.
    return;
  }
  uint32_t len = readLE32(header + 4);
  if (len == 0 || len > MAX_JPEG_BYTES) return;
  if (!readExact(jpegBuf, len, 3000)) return;

  if (jpeg.openRAM(jpegBuf, len, jpegDraw)) {
    jpeg.decode(0, 0, 0);
    jpeg.close();
  }
}

void setup() {
  Serial.begin(USB_BAUD);
  delay(250);
  initDisplay();

  pinMode(PIN_TOUCH_RST, OUTPUT);
  digitalWrite(PIN_TOUCH_RST, LOW);
  delay(5);
  digitalWrite(PIN_TOUCH_RST, HIGH);
  delay(50);
  pinMode(PIN_TOUCH_INT, INPUT_PULLUP);
  Wire.begin(PIN_TOUCH_SDA, PIN_TOUCH_SCL, 400000);

  jpegBuf = (uint8_t *)ps_malloc(MAX_JPEG_BYTES);
  if (!jpegBuf) jpegBuf = (uint8_t *)malloc(MAX_JPEG_BYTES);
  if (!jpegBuf) showSplash("ERROR", "No JPEG buffer");
  else showSplash("USB CDC ready", "Connect Android app");
}

void loop() {
  if (jpegBuf) processUsbFrame();
  pollTouch();
  delay(1);
}
