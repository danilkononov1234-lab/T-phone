package com.tremote.s3usb

import android.app.Activity
import android.content.*
import android.hardware.usb.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val usbPermissionAction = "com.tremote.s3usb.USB_PERMISSION"
    private val captureRequest = 701
    private lateinit var status: TextView
    private lateinit var link: UsbCdcLink
    private var selected: UsbDevice? = null

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == usbPermissionAction) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted && device != null) connectAndStart(device)
                else status.text = "USB permission denied"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        link = UsbCdcLink(this)
        registerReceiver(usbReceiver, IntentFilter(usbPermissionAction), RECEIVER_NOT_EXPORTED)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 40, 24, 20) }
        box.addView(TextView(this).apply { text = "T-REMOTE S3 USB"; textSize = 25f })
        status = TextView(this).apply { text = "Connect T-Display-S3 with USB-C" }
        box.addView(status)
        box.addView(Button(this).apply {
            text = "Connect USB"
            setOnClickListener { findDevice() }
        })
        box.addView(Button(this).apply {
            text = "Start mirror"
            setOnClickListener {
                if (selected == null) { status.text = "Сначала Connect USB"; return@setOnClickListener }
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
            }
        })
        box.addView(Button(this).apply {
            text = "Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(box)
    }

    private fun findDevice() {
        val device = link.devices().firstOrNull()
        if (device == null) { status.text = "USB device not found. Check OTG cable."; return }
        selected = device
        if (link.hasPermission(device)) connectAndStart(device)
        else {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(usbPermissionAction).setPackage(packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            (getSystemService(USB_SERVICE) as UsbManager).requestPermission(device, pi)
        }
    }

    private fun connectAndStart(device: UsbDevice) {
        if (!link.open(device)) { status.text = "CDC interface not found"; return }
        UsbLinkHolder.link = link
        link.startReader { x, y, down ->
            if (down) RemoteAccessibilityService.performRemoteTap(x, y)
        }
        status.text = "USB connected: ${device.deviceName}"
    }

    @Deprecated("Use Activity Result API in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, MirrorService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            startForegroundService(intent)
            status.text = "Mirror active — tap screen to control"
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        link.close()
        super.onDestroy()
    }
}

object UsbLinkHolder {
    @Volatile var link: UsbCdcLink? = null
}
