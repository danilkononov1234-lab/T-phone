package com.tremote.s3usb

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class RemoteAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        @Volatile private var instance: RemoteAccessibilityService? = null
        fun performRemoteTap(rx: Int, ry: Int) {
            instance?.tap(rx, ry)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    private fun tap(rx: Int, ry: Int) {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val x = (rx / 170f * dm.widthPixels).coerceIn(0f, dm.widthPixels - 1f)
        val y = (ry / 320f * dm.heightPixels).coerceIn(0f, dm.heightPixels - 1f)
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 70)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
