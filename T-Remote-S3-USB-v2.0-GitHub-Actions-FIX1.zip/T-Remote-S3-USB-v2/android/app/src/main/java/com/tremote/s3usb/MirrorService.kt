package com.tremote.s3usb

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

class MirrorService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private val busy = AtomicBoolean(false)
    private var lastFrame = 0L
    private val w = 170
    private val h = 320

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channel = "tremote_usb"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "T-Remote USB", NotificationManager.IMPORTANCE_LOW))
        }
        startForeground(20, Notification.Builder(this, channel)
            .setContentTitle("T-Remote S3 USB")
            .setContentText("Screen mirroring is active")
            .setSmallIcon(android.R.drawable.ic_menu_view).build())

        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))
        startCapture()
        return START_NOT_STICKY
    }

    private fun startCapture() {
        worker = HandlerThread("TRemoteUsbFrames").also { it.start() }
        val handler = Handler(worker!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (now - lastFrame < 100 || !busy.compareAndSet(false, true)) {
                r.acquireLatestImage()?.close(); return@setOnImageAvailableListener
            }
            val image = r.acquireLatestImage()
            if (image == null) { busy.set(false); return@setOnImageAvailableListener }
            lastFrame = now
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val paddedWidth = rowStride / pixelStride
                val raw = Bitmap.createBitmap(paddedWidth, h, Bitmap.Config.ARGB_8888)
                raw.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(raw, 0, 0, w, h)
                raw.recycle()
                val out = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, 55, out)
                cropped.recycle()
                sendFrame(out.toByteArray())
            } finally {
                image.close()
                busy.set(false)
            }
        }, handler)

        display = projection?.createVirtualDisplay(
            "T-Remote-S3", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
    }

    private fun sendFrame(jpeg: ByteArray) {
        val link = UsbLinkHolder.link ?: return
        val header = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            .put(byteArrayOf('T'.code.toByte(), 'R'.code.toByte(), 'F'.code.toByte(), '1'.code.toByte()))
            .putInt(jpeg.size).array()
        link.write(header)
        link.write(jpeg)
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        worker?.quitSafely()
        super.onDestroy()
    }
}
