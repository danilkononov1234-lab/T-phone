package com.tremote.s3usb

import android.content.Context
import android.hardware.usb.*
import java.util.concurrent.atomic.AtomicBoolean

class UsbCdcLink(private val context: Context) {
    private val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var connection: UsbDeviceConnection? = null
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private var controlInterface: UsbInterface? = null
    private val running = AtomicBoolean(false)

    fun devices(): List<UsbDevice> = manager.deviceList.values.toList()
    fun hasPermission(device: UsbDevice) = manager.hasPermission(device)

    fun open(device: UsbDevice): Boolean {
        close()
        val conn = manager.openDevice(device) ?: return false
        var dataIntf: UsbInterface? = null
        var ctrlIntf: UsbInterface? = null
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) dataIntf = intf
            if (intf.interfaceClass == UsbConstants.USB_CLASS_COMM) ctrlIntf = intf
        }
        // Some CDC-ACM firmwares expose bulk endpoints on one interface; locate them regardless.
        if (dataIntf == null) {
            loop@ for (i in 0 until device.interfaceCount) {
                val intf = device.getInterface(i)
                for (j in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(j)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep
                        else outEp = ep
                    }
                }
                if (inEp != null && outEp != null) { dataIntf = intf; break@loop }
            }
        }
        if (dataIntf == null) { conn.close(); return false }

        if (inEp == null || outEp == null) {
            for (j in 0 until dataIntf.endpointCount) {
                val ep = dataIntf.getEndpoint(j)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
                }
            }
        }
        if (inEp == null || outEp == null) { conn.close(); return false }

        if (ctrlIntf != null) {
            conn.claimInterface(ctrlIntf, true)
            controlInterface = ctrlIntf
            // CDC SET_CONTROL_LINE_STATE: DTR=1, RTS=0
            conn.controlTransfer(0x21, 0x22, 1, ctrlIntf.id, null, 0, 1000)
        }
        if (!conn.claimInterface(dataIntf, true)) { conn.close(); return false }
        connection = conn
        return true
    }

    fun startReader(onTouch: (Int, Int, Boolean) -> Unit) {
        val conn = connection ?: return
        val ep = inEp ?: return
        if (!running.compareAndSet(false, true)) return
        Thread {
            val buf = ByteArray(64)
            val stream = ArrayList<Byte>()
            while (running.get()) {
                val n = conn.bulkTransfer(ep, buf, buf.size, 250)
                if (n > 0) {
                    for (i in 0 until n) stream.add(buf[i])
                    while (stream.size >= 9) {
                        var idx = -1
                        for (i in 0..stream.size - 4) {
                            if (stream[i] == 'T'.code.toByte() &&
                                stream[i+1] == 'R'.code.toByte() &&
                                stream[i+2] == 'T'.code.toByte() &&
                                stream[i+3] == '1'.code.toByte()) { idx = i; break }
                        }
                        if (idx < 0) {
                            while (stream.size > 3) stream.removeAt(0)
                            break
                        }
                        repeat(idx) { stream.removeAt(0) }
                        if (stream.size < 9) break
                        val x = (stream[4].toInt() and 255) or ((stream[5].toInt() and 255) shl 8)
                        val y = (stream[6].toInt() and 255) or ((stream[7].toInt() and 255) shl 8)
                        val down = stream[8].toInt() != 0
                        repeat(9) { stream.removeAt(0) }
                        onTouch(x, y, down)
                    }
                }
            }
        }.apply { name = "TRemoteUsbReader"; isDaemon = true; start() }
    }

    @Synchronized fun write(bytes: ByteArray): Boolean {
        val conn = connection ?: return false
        val ep = outEp ?: return false
        var offset = 0
        while (offset < bytes.size) {
            val count = minOf(ep.maxPacketSize.coerceAtLeast(64) * 16, bytes.size - offset)
            val part = bytes.copyOfRange(offset, offset + count)
            val sent = conn.bulkTransfer(ep, part, part.size, 3000)
            if (sent <= 0) return false
            offset += sent
        }
        return true
    }

    fun close() {
        running.set(false)
        try { controlInterface?.let { connection?.releaseInterface(it) } } catch (_: Exception) {}
        try { connection?.close() } catch (_: Exception) {}
        connection = null; inEp = null; outEp = null; controlInterface = null
    }
}
